from tkinter import *
from tkinter import ttk
from tkinter import filedialog

from ChooseCsvHeaders import ChooseCsvHeaders
from ModelPage import ModelPage

# TODO:
    # Write instructions page
    # Specify starred imports explicitly
    
class HomePage:

    def __init__(self,root,frame,app):

        self.root = root
        self.frame = frame
        self.app = app

        # Instantiated on loadCSV click
        self.header_page = None
        self.csv_file_string = None

        self.model_page = ModelPage(self.root,self.app.addPageFrame("model frame",self.root),self.app)
        self.configurePage()

        self.full_screen = False
    
    def configurePage(self):
        """        

        Configures the homepage frame/page layout    
        
        """        
        self.frame.grid(column=0, row=0, sticky="NSEW")
        self.frame.columnconfigure(1,weight=2)
        self.frame.rowconfigure(1,weight=1)
        self.frame.columnconfigure(0,weight=1)
        self.frame.rowconfigure(0,weight=1)
        self.frame.columnconfigure(2,weight=1)
        
        title = ttk.Label(self.frame, justify=CENTER, text = "Patient\n\nFree Text\n\nExplorer", font=("bold",25))
        title.grid(column=1, columnspan=1,row=0,rowspan=1)
        self.csv_file_string = StringVar()
        self.csv_file_string.set("The name of your CSV file will appear here")
        csv_name_box = Label(self.frame, textvariable = self.csv_file_string)
        csv_name_box.grid(column = 1, row = 2, sticky="NSEW")
        load_csv_button = ttk.Button(self.frame, text="Open CSV", command = self.loadCSVClick)
        load_csv_button.grid(column=1, row=3,sticky=(N,S,E,W))
        instruction_button = ttk.Button(self.frame, text="Instructions", command=self.instructionsClick)
        instruction_button.grid(column=1,row=6,sticky=(N,S,E,W))
        model_button = ttk.Button(self.frame, text="Predict MS Type", command= lambda: self.app.displayFrame("model frame"))
        model_button.grid(column=1,row=5,sticky=(N,S,E,W))

        full_screen_button = ttk.Button(self.frame, text = "Toggle Fullscreen", command = self.fullscreen)
        full_screen_button.grid(column=1,row=7,sticky=(N,S,E,W))

        # Disabled by default
        # Set to normal by ChooseCsvHeaders.chooseCsvHeaders() function
        self.main_menu_button = ttk.Button(self.frame, 
                                           text = "Main Menu", 
                                           state = DISABLED, 
                                           command = lambda: self.app.displayFrame("main frame"))
        self.main_menu_button.grid(column = 1, row = 4, sticky = NSEW)

    def fullscreen(self):
        
        if ( self.full_screen == False ):
            self.app.root.attributes('-fullscreen', True)
            self.full_screen = True
        else:
            self.app.root.attributes('-fullscreen', False)
            self.full_screen = False

    
    def loadCSVClick(self):       
        
        """
        Opens a file dialog window that only allows the user to choose a csv file
        
        After a file is selected, set up the relevant data and open the chooseCSVHeaders page

        """

        # Only permit CSV files, returns the full file path        
        csv_file = filedialog.askopenfilename(title = "Select a CSV file", 
                                              filetypes=(("csv files", "*.csv"),
                                                         ))
        if csv_file == "":
            return
        else:
            self.csv_file_string.set(csv_file.rsplit('/', 1)[1])
        # initialise class for csv page frame
        self.header_page = ChooseCsvHeaders(self.root, 
                                            self.app, 
                                            self.app.addPageFrame("choose headers", 
                                                                  self.root), 
                                            csv_file)
        # set up data for csv page and display the page
        self.header_page.chooseCSVHeaders()
        #self.app.displayFrame("choose headers") # part of above function?

    def instructionsClick(self):
        
        """
        Opens the instruction page which tells the user how to use our software

        """
        print("Need to display instructions")
    

        